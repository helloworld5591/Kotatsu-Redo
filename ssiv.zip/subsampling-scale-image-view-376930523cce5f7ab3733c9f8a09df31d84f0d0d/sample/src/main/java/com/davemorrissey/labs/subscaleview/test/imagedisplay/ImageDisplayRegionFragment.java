package com.davemorrissey.labs.subscaleview.test.imagedisplay;

import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.davemorrissey.labs.subscaleview.ImageSource;
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView;
import com.davemorrissey.labs.subscaleview.decoder.CompatDecoderFactory;
import com.davemorrissey.labs.subscaleview.decoder.ImageDecoder;
import com.davemorrissey.labs.subscaleview.decoder.ImageRegionDecoder;
import com.davemorrissey.labs.subscaleview.decoder.SkiaImageDecoder;
import com.davemorrissey.labs.subscaleview.decoder.SkiaImageRegionDecoder;
import com.davemorrissey.labs.subscaleview.test.R.id;
import com.davemorrissey.labs.subscaleview.test.R.layout;

public class ImageDisplayRegionFragment extends Fragment {

	@Override
	public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		View rootView = inflater.inflate(layout.imagedisplay_region_fragment, container, false);
		final SubsamplingScaleImageView imageView = rootView.findViewById(id.imageView);
		imageView.setBitmapDecoderFactory(new CompatDecoderFactory<ImageDecoder>(SkiaImageDecoder.class, Bitmap.Config.ARGB_8888));
		imageView.setRegionDecoderFactory(new CompatDecoderFactory<ImageRegionDecoder>(SkiaImageRegionDecoder.class, Bitmap.Config.ARGB_8888));
		imageView.setOrientation(SubsamplingScaleImageView.ORIENTATION_90);
		imageView.setImage(ImageSource.asset("card.png").region(new Rect(5200, 651, 8200, 3250)));
		final ImageDisplayActivity activity = (ImageDisplayActivity) getActivity();
		if (activity != null) {
			rootView.findViewById(id.previous).setOnClickListener(v -> activity.previous());
		}
		rootView.findViewById(id.rotate).setOnClickListener(v -> imageView.setOrientation((imageView.getOrientation() + 90) % 360));
		return rootView;
	}

}
